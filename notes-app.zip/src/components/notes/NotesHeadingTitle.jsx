const NotesHeadingTitle = () => {
  return (
    <h1 className="text-3xl poppins-semibold text-primary">Daftar Catatan</h1>
  );
};

export default NotesHeadingTitle;
